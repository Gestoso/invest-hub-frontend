export const environment = {
  apiUrl: '/api/v1'
};
